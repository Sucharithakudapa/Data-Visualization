1.Install nodejs, check for node --version in command line if you can't able to see anything or get any error set the environment variables properly
2.run command 'install npm' if you don't have npm installed in your system 
3.then start the the application using command 'npm start'
4.AS the application is running by default in port 4000 go to chrome or any other browser type 'localhost:4000'
5.Then you can able to see the application
